In this zipped files, it has
HomeInterview-YD.pdf: to present my ideas and result
crypto_arbe_result.xlsx: trader generated results
trader_log.log: trader log file. by running: python crypto_arbe.py > trader_log.log
source code: crypto_arbe.py.txt
